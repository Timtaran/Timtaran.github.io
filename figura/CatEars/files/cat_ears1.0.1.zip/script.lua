animations.model.idle:stop()
animations.model.wing:stop()

function playWing()
    sounds:playSound("ui.toast.in",player:getPos(), 0.05)
    animations.model.wing:play()
end

function idleState(state)
   if (state) then
    animations.model.idle:play()
   else
    animations.model.idle:stop()
   end
end
local wingAnimKey = keybinds:newKeybind("Wing Ears", "key.keyboard.h")
local state

local keybindState = false
function pings.examplePing(state)
    keybindState = state
end

wingAnimKey.press = function() pings.examplePing(true) end
wingAnimKey.release = function() pings.examplePing(false) end

function events.tick()
    if (keybindState) then
        if (animations.model.wing:getPlayState() == "STOPPED") then
            playWing()
        end
    end
end

local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)
local Wing = mainPage:newAction()
    :title("Wing")
    :item("minecraft:feather")
    :hoverColor(1,0,1)
    :onLeftClick(playWing)
    :onRightClick(playWing)

local Idle = mainPage:newAction()
    :title("Idle")
    :hoverColor(0,1,1)
    :item("red_wool")
    :toggleItem("lime_wool")
    :onToggle(idleState)